package com.github;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import org.apache.commons.io.IOUtils;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Map;

public class Main {

    // URL de conexão com o banco de dados MySQL
    private static final String DB_URL = "jdbc:mysql://localhost:3306/tdejava?useSSL=false";
    // Usuário do banco de dados
    private static final String DB_USER = "root";
    // Senha do banco de dados
    private static final String DB_PASSWORD = "Ann4L1nd4";
    // Query SQL para inserir dados na tabela filme
    private static final String INSERT_SQL = "INSERT INTO filme (nome, ano, genero, ondeAssistir) VALUES (?, ?, ?, ?)";

    public static void main(String[] args) {
        final int PORT = 8080; // Porta onde o servidor vai escutar

        try (ServerSocket serverSocket = new ServerSocket(PORT)) {
            System.out.println("Servidor iniciado na porta " + PORT);

            while (true) {
                try {
                    // Aceita conexão de um cliente
                    Socket clientSocket = serverSocket.accept();
                    System.out.println("Usuário conectado: " + clientSocket.getInetAddress().getHostAddress());

                    // Cria uma nova thread para lidar com a conexão do cliente
                    Thread thread = new Thread(() -> {
                        try (
                                BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
                                Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)
                        ) {
                            // Lê a requisição HTTP
                            StringBuilder requestData = new StringBuilder();
                            String line;
                            while ((line = in.readLine()) != null && !line.isEmpty()) {
                                requestData.append(line);
                            }
                            String lineRequest = requestData.toString();
                            System.out.println("Request: " + lineRequest);

                            // Lê o corpo da requisição
                            StringBuffer bodyBuffer = new StringBuffer();
                            while (in.ready()) {
                                bodyBuffer.append((char) in.read());
                            }
                            String body = bodyBuffer.toString();
                            System.out.println("Body: " + body);

                            // Trata diferentes tipos de requisições
                            if (requestData.toString().startsWith("POST /submit")) {
                                System.out.println("Recebida requisição POST para /submit");
                                clientSocket.getOutputStream().write("HTTP/1.1 200 OK\r\n\r\n".getBytes());
                                handlerSubmit(conn, body, clientSocket.getOutputStream());
                            } else if (requestData.toString().startsWith("GET / ")) {
                                System.out.println("Recebida requisição GET para /");
                                clientSocket.getOutputStream().write("HTTP/1.1 200 OK\r\n\r\n".getBytes());
                                InputStream input = Main.class.getResourceAsStream("/frontend/index.html");
                                byte[] byteArray = IOUtils.toByteArray(input);
                                clientSocket.getOutputStream().write(byteArray);
                            } else if (requestData.toString().startsWith("OPTIONS")) {
                                System.out.println("Recebida requisição OPTIONS");
                                clientSocket.getOutputStream().write("HTTP/1.1 200 OK\r\n\r\n".getBytes());
                            }

                            System.out.println("Dados recebidos do usuário:");
                            System.out.println(requestData);

                        } catch (Exception e) {
                            e.printStackTrace();
                        } finally {
                            try {
                                // Fecha a conexão com o cliente
                                clientSocket.close();
                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                        }
                    });

                    // Inicia a thread
                    thread.start();

                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Método para lidar com requisições POST /submit
    public static void handlerSubmit(Connection conn, String body, OutputStream out) throws Exception {
        Gson gson = new Gson();
        TypeToken<Map<String, String>> mapType = new TypeToken<>() {};
        // Converte o corpo da requisição JSON para um Map
        Map<String, String> stringMap = gson.fromJson(body, mapType);
        System.out.println("Map: " + stringMap);

        try {
            // Prepara a inserção no banco de dados
            PreparedStatement stmt = conn.prepareStatement(INSERT_SQL);
            stmt.setString(1, stringMap.get("nome"));
            stmt.setString(2, stringMap.get("ano"));
            stmt.setString(3, stringMap.get("genero"));
            stmt.setString(4, stringMap.get("ondeAssistir"));

            // Executa a inserção e verifica se teve sucesso
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Dados inseridos no banco de dados.");
                out.write("Dados recebidos e inseridos no banco de dados.".getBytes());
            } else {
                System.out.println("Falha ao inserir dados no banco de dados.");
                out.write("Falha ao inserir dados no banco de dados.".getBytes());
            }
        } catch (SQLException e) {
            e.printStackTrace();
            out.write("Erro ao inserir dados no banco de dados.".getBytes());
        }
    }
}
